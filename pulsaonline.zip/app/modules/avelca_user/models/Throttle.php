<?php namespace App\Modules\Avelca_User\Models;

class Throttle extends \Eloquent {

	/* Eloquent */
	protected $table = "throttle";
	public $timestamps = true;
	
}