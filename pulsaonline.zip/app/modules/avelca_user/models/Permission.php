<?php namespace App\Modules\Avelca_User\Models;

class Permission extends \Eloquent {

	/* Eloquent */
	protected $table = "permissions";
	public $timestamps = true;
	
}