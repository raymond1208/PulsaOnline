<?php

class StatusController extends AvelcaController {

	public function __construct(\Status $Model)
	{
		parent::__construct($Model);
	}

}