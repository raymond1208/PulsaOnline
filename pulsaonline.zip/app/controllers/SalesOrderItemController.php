<?php

class SalesOrderItemController extends AvelcaController {

	public function __construct(\SalesOrderItem $Model)
	{
		parent::__construct($Model);
	}

}