<?php

class BankController extends AvelcaController {

	public function __construct(\Bank $Model)
	{
		parent::__construct($Model);
	}

}