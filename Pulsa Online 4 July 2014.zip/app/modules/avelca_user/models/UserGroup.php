<?php namespace App\Modules\Avelca_User\Models;

class UserGroup extends \Eloquent {

	/* Eloquent */
	protected $table = "users_groups";
	public $timestamps = false;
		
}