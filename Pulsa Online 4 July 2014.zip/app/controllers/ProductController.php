<?php

class ProductController extends AvelcaController {

	public function __construct(\Product $Model)
	{
		parent::__construct($Model);
	}

}