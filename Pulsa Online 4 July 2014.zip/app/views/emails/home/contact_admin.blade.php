<p>Full Name : {{ $full_name }}</p>
<p>Email : {{ $email }}</p>
<p>Message : </p>
{{ $visitor_message }}