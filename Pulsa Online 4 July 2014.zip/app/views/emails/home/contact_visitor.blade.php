<p>Hi {{ $full_name }},</p>

<p>Thank you for contacting us. Below is the email we received :</p><br>

<p>Full Name : {{ $full_name }}</p>
<p>Email : {{ $email }}</p>
<p>Message : </p>
{{ $visitor_message }}